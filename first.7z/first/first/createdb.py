import sqlite3 as lite
import sys
F = open('db1','r')

E = open('finaldb', 'w')

l = None

for line in F.readlines():
    l = line.encode('cp1252').decode('utf-8')
    l = l.replace('`','"')
    l = l.replace("\\'","''")
    E.write(l)

F.close()

E.close()

con = lite.connect('test.db')

i=0

with con:
    cur = con.cursor()
    cur.execute("PRAGMA encoding = 'UTF-8';")
    cur.execute('DROP TABLE IF EXISTS "catalogue"')
    cur.execute('CREATE TABLE catalogue (auteur text,titre text,collection text, numcoll int(11) DEFAULT NULL,editeur text, date int(11) DEFAULT NULL,isbn varchar(20) DEFAULT NULL, ams text,  cle text,cote varchar(15) DEFAULT NULL, inventaire text,type varchar(10) DEFAULT NULL,lang varchar(4) DEFAULT NULL, lango varchar(4) DEFAULT NULL, numfiche int(11) NOT NULL DEFAULT "0",PRIMARY KEY ("numfiche"));')
    DB = open('finaldb', 'r')
    for line in DB.readlines():
        i+=1
        l = line.encode('cp1252').decode('utf-8')
        print(l)
        cur.execute(l)
    lid = cur.lastrowid
    print("The last Id of the inserted row is %d" % lid)

#database population

con_old = lite.connect('test.db')
con_new = lite.connect('db.sqlite3')
cur_old = con_old.cursor()
cur_new = con_new.cursor()
cur_old.execute('select * From catalogue')
while cur.fetchone():
    cur_new.execute('insert ')
