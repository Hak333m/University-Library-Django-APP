from django.db import models


class Commande(models.Model):
    numcom = models.IntegerField( primary_key= True)
    auteur = models.TextField()
    titre = models.TextField()
    editeur = models.CharField(max_length=60)
    demandeur = models.CharField(max_length=20)
    commentaire = models.TextField()
    prix = models.IntegerField()
    etat = models.CharField(max_length=1)
    isbn = models.CharField(max_length=20)
    fourniseur = models.CharField(max_length=15)
    date = models.DateField()


class Catalogue(models.Model):
    numfiche = models.IntegerField(primary_key=True)
    numcom = models.ForeignKey(Commande,blank=True,null=True, on_delete=models.CASCADE)
    #titre = models.TextField()
    auteur = models.TextField()
    collection = models.TextField()
    numcoll = models.IntegerField()
    editeur = models.TextField()
    date = models.TextField()
    isbn = models.CharField(max_length=20)
    ams = models.TextField() # A revoir ?
    cle = models.TextField() #?
    type = models.CharField(max_length=10)
    long = models.CharField(max_length=4)
    longo = models.CharField(max_length=4)


class Utilisateurs(models.Model):
    identifiant = models.CharField(max_length=15, primary_key=True)
    identité = models.CharField(max_length=50)
    role = models.IntegerField()
    divers = models.TextField(blank=True)

class Livre(models.Model):
    inventaire = models.CharField(primary_key=True, max_length=11)
    numfiche = models.ForeignKey(Catalogue, on_delete=models.CASCADE)
    cote = models.CharField(max_length=15)
    empreinte = models.NullBooleanField()
    diponiblity = models.IntegerField()
    perdu = models.NullBooleanField()


class Empreint(models.Model):
    numemprunt = models.IntegerField( primary_key=True)
    identifiant = models.ForeignKey(Utilisateurs, on_delete=models.CASCADE)
    inventaire = models.ForeignKey(Livre, on_delete=models.CASCADE)
    date = models.DateField()
    date_retour =  models.DateField()


class Saisie(models.Model):
    numfiche = models.CharField(max_length=11,blank=True)
    numcom = models.CharField(max_length=11,blank=True)
    auteur = models.TextField()
    collection = models.TextField()
    numcoll = models.IntegerField()
    editeur = models.TextField()
    date = models.TextField()
    isbn = models.CharField(max_length=20)
    ams = models.TextField() # A revoir ?
    inventaire= models.TextField()
    cote = models.CharField(max_length=15)
    cle = models.TextField() #?
    type = models.CharField(max_length=10)
    long = models.CharField(max_length=4)
    longo = models.CharField(max_length=4)
    saisieur = models.TextField()
    valide = models.IntegerField()
















