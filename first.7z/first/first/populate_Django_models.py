from books import models

import sqlite3 as lite

con = lite.connect('test.db')

c = con.cursor()

c.execute('select * From catalogue')

for row in c.fetchall():
    auteur = row[0]
    #titre = row[1]
    collection = row[2]
    numcoll = row[3]
    editeur = row[4]
    date = row[5]
    isbn = row[6]
    ams = row[7]
    cle = row[8]
    cote = row[9]
    inventaire = row[10]
    type = row[11]
    lang = row[12]
    lango = row[13]
    numfiche = row[14]
    catalogues = models.Catalogue(numfiche = numfiche, auteur= auteur, \
                                  collection=collection, numcoll=numcoll,\
                                  editeur = editeur, date=date,\
                                  isbn = isbn,ams = ams,cle=cle,\
                                  type=type,long=lang,longo=lango)
    catalogues.save()
    if '\\' in inventaire:
        inventaire = inventaire.split('\\')
    for i in range(len(inventaire)):
        livre = models.Livre(inventaire = inventaire[i], numfiche=numfiche,\
                          cote = cote,disponibility=1, empreinte = 0, perdu=False)
        livre.save()